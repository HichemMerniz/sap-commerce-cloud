import './polyfills.server.mjs';
import{c as o,d as r,e as n}from"./chunk-DLZHC5VP.mjs";import{Jc as e}from"./chunk-JSDTXUAI.mjs";import"./chunk-GHFNAT2I.mjs";export{n as renderApplication,r as renderModule,e as \u0275Console,o as \u0275SERVER_CONTEXT};
